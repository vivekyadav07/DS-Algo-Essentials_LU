#include<stdio.h>  
#include<stdlib.h>  
//Create a basic structure for NODE from which new nodes can be created.  
struct node  
{  
    int data;  
    struct node *link;  
};  
struct node *header, *ptr, *ptr1, *temp;  
void delete_any();  
int main()  
{  
    int choice;  
    int cont = 1;  
    header = (struct node *) malloc(sizeof(struct node));  
  
    //Set the content of header node  
    header->data = NULL;  
    header->link = NULL;  
delete_any();  
printf("\nContents of the linked list are: \n");  
    //Print the contents of the linked list starting from header  
    ptr = header;  
    while(ptr->link != NULL)  
    {  
        ptr = ptr->link;  
        printf("%d ", ptr->data);  
    }  
return 0;  
}  
//Function to delete any node from linked list.  
void delete_any()  
{  
    int key;  
    if(header->link == NULL)  
    {  
        printf("\nEmpty Linked List. Deletion not possible.\n");  
    }  
    else  
    {  
        printf("\nEnter the data of the node to be deleted: ");  
        scanf("%d", &key);  
        ptr = header;  
        while((ptr->link != NULL) && (ptr->data != key))  
        {  
            ptr1 = ptr;  
            ptr = ptr->link;  
        }  
        if(ptr->data == key)  
        {  
            ptr1->link = ptr->link;  
            free(ptr);  
            printf("\nNode with data %d deleted.\n", key);  
        }  
        else  
        {  
            printf("\nValue %d not found. Deletion not possible.\n", key);  
        }         
    }  
}  